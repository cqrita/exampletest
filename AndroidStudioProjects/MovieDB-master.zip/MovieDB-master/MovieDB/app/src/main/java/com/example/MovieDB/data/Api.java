package com.example.MovieDB.data;


import com.example.MovieDB.BuildConfig;

public final class Api {
    public static final String apikey2 = BuildConfig.apikey2;

    public String getApikey2() {
        return apikey2;
    }
}
